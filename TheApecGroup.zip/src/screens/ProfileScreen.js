import { Text } from "react-native";

export default function ProfileScreen() {
  return <Text style={{ fontSize: 50 }}>ProfileScreen</Text>;
}
