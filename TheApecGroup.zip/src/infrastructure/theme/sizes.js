export const sizes = [8, 16, 32, 64, 128];
