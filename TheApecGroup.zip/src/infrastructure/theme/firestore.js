export const USER_COLLECTION = "theApecGroup_users";
export const TABS_COLLECTION = "theApecGroup_folders";
export const CONTENT_COLLECTION = "theApecGroup_content";
